const date = new Date();

document.getElementById("copyright").innerHTML = `Copyright &copy; ${date.getFullYear()}. All rights reserved for Vignesh Ravichandran.`